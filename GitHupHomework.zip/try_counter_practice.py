import threading

class Counter:
    def __init__(self):
        self.count = 0
        self.lock = threading.Lock()
    def increase(self):
        '''with bloğu aynı anda self.lock.acquire() ve self.lock.release() işemlerini aynı anda yapar
        bu kısma girdiğinde her bir  thread lock'ı alır self.lock.acquire() burda bekler işlem bitene kadar hiç bir thread bu with bloğuna giremez işlem bitince
        self.lock.acquire() bunu çalıştırır lock serbest kalır ve yeni bir threadi için egelir bu şekilde herr seferinde sadec bir thread'in counter nesnesine ulaşıp değerini değiştirlmesi sağlanır 
        probelm çzöülür ancak çok zaman performansı açısından çok kötü olur  
        peformasnı artırmka için her aşamda lock yapılamaz başta ve sonda lock mekanizması 10 şifre isteği her biri çözüp en son lock ile çözebilen göndericek
             
        '''
        with self.lock:
            self.count += 1

class IncreaseCounter(threading.Thread):
    def __init__(self, counter, n):
        super().__init__()
        self.counter = counter
        self.n = n
    def run(self):
        for _ in range(self.n):
            self.counter.increase()

def main(n: int, m: int):
    counter = Counter()
    threads = []
    for _ in range(m):
        t = IncreaseCounter(counter, n)
        threads.append(t)
    for  thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    print(f"Expected: {n*m}, Actual: {counter.count}")
    return counter.count

if __name__ == "__main__":
   main(1000000,4)

'''
   main(10000,4)
rogrammingVSCode/try_counter_practice.py
Expected: 40000, Actual: 40000
PS C:\ParallelProgrammingVSCode> 
küçük sayılar için hata  olmazken
main(1000000,4)
PS C:\ParallelProgrammingVSCode> & C:/ProgramData/Anaconda3/python.exe c:/ParallelProgrammingVSCode/try_counter_practice.py
Expected: 4000000, Actual: 2614694
PS C:\ParallelProgrammingVSCode> ^C
PS C:\ParallelProgrammingVSCode>   
çok büyük değerler için ortay çıkan bu problemi önlemek gerekir bu Probleme 
Race Condition denir
Lock kullanılarak bu problem önlenilir
PS C:\ParallelProgrammingVSCode> & C:/ProgramData/Anaconda3/python.exe c:/ParallelProgrammingVSCode/try_counter_practice.py
Expected: 4000000, Actual: 4000000
PS C:\ParallelProgrammingVSCode> 
çözümü bu şekilde doğru verdi ancak time performansı açıısndan çok kötü
'''