import tracemalloc
import time

def performance(func):
    if not hasattr(performance , 'counter'):
        performance.counter = 0
        performance.total_time = 0
        performance.total_mem = 0

    def perform(*args,**kwargs):
        tracemalloc.start()  # start to follow memory
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        used_memory = tracemalloc.get_traced_memory()[1]  # [0] gives current memory consumption but [1] gives total(max) memory consumption during thr last fallowing time
        tracemalloc.stop()  # we started memeory following process only to find how much memory uses by thr called function not the entire program ,so we stop memory following when the jop of function is finished
        performance.counter += 1
        performance.total_time += end_time - start_time
        performance.total_mem += used_memory
        print(performance.counter)
        #print(type(performance.counter)) int type
        print(performance.total_time)
        print(performance.total_mem)
        return result
    return perform


@performance
def sample_function(x,y):
    return x+y

print(sample_function(5, 10))
print(sample_function(15, 17))




'''class Performance:
    def __init__(self):
        self.total_time = 0
        self.counter = 0
        self.total_mem = 0

    def performance(self,func):
        def performance_(*args,**kwargs):
            tracemalloc.start()  #start to follow memory
            start_time = time.time()
            result = func(*args,**kwargs)
            end_time = time.time()
            used_memory = tracemalloc.get_traced_memory()[1] #[0] gives current memory consumption but [1] gives total(max) memory consumption during thr last fallowing time
            tracemalloc.stop() # we started memeory following process only to find how much memory uses by thr called function not the entire program ,so we stop memory following when the jop of function is finished
            self.counter += 1
            self.total_time += end_time - start_time
            self.total_mem += used_memory
            return result
        return performance_

performance_object = Performance()
@performance_object.performance
def sample_function(x,y):
    return x+y

print(sample_function(5, 10))
print(sample_function(10,90))
print(f"Total calls: {performance_object.counter}, Total time: {performance_object.total_time:.4f}s, Total memory: {performance_object.total_mem} bytes")'''









'''
from time import perf_counter
import tracemalloc

def performance(fn):
    if not hasattr(performance, 'counter'):
            performance.counter = 0
            performance.total_time = 0
            performance.total_mem = 0

    def _performance(*args, **kwargs):
        tracemalloc.start()
        start = perf_counter()
        result = fn(*args, **kwargs)
        end = perf_counter()
        performance.total_mem += tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        performance.counter += 1
        performance.total_time += end - start
        return result
    return _performance
'''