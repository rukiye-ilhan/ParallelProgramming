import threading
import time
#thread üreten fonksiyon create thread from a function
def create_thread_from_function():
    def thread_1():
        print(
            f"this is a thread created from a function"
            f"with id {threading.get_native_id()}"
        )
    t = threading.Thread(target=thread_1)
    t.start()

#class üzerinden thread üretmeki bu en çok tercih edilendir
'''hali hazırda bir thread classı var saten bizde bir thread üreten ve onun üzerinden 
işlemler yapan bir class üretmek istiyoruz bunun için önce ana ata classın özelliklerini 
kullanmak üzere super keywordu kullanıyoruz yani takild eden ama eklemtielr yapılan yeni bir thread classı
'''
def create_thread_from_class():
    class Thread2(threading.Thread):
        def __init__(self):
            super().__init__()
        def run(self):
            print(
                f"this is a thread created from a class"
                f"with id{threading.get_native_id()}"
            )
    t = Thread2()
    t.start()

#thread yapmak üzere kullanacağımız fonksiyonların parametreleri olabilir
def create_thread_from_function_and_pass_arguments():
    def thread_3(s):
        print(
            f"this is a thread created from a function "
            f" with id {threading.get_native_id() }"
            f" and your argument is {s}"
        )  
    t = threading.Thread(target=thread_3, args=("thread 3",))
    t.start()

#Create two threads and join them
#birden fazla oluşturlan threadler varsa join edildiklerinde main thread bütün threadlerin bitimine kadar bekler
#main thread biten threadleri bekleterek hepsi bittiğinde işlemleri sonlandırır
#Eper bir thread başka bir threadi çağırmışsa çağırdığı thread işlemini bitirmeden 
#başka bir işleme devam etmek istemiyorsa join kullanılır.
#threadlerin sıralı bir şekilde çalışmasını sağlamak için kullanılır
#veri tabanı veya dosya işlemlerinde kaynakların verimli düzenli kullanımında threadler arasında bekletilme işlemi yapılabilir

def create_two_threads_and_join_them():
    def thread_4_1():
        print(f"this is thread_4_1 with id {threading.get_native_id()}")
        time.sleep(1)
        print(f"thread_4_1 is done")
    
    def thread_4_2():
        print(f"this is thread_4_2 with id {threading.get_native_id()}")
        time.sleep(3)
        print(f"thread_4_2 is done")
    
    def thread_4_3():
        print(f"this is thread_4_3 with id {threading.get_native_id()}")
        print(f"I can only start after thread 4_1 and thread 4_2 are done")
        time.sleep(1)
        print(f"thread_4_3 is done")

    t1 = threading.Thread(target=thread_4_1)
    t2 = threading.Thread(target=thread_4_2)
    t3 = threading.Thread(target=thread_4_3)
    t1.start()
    t2.start()
    #t1 ve t2 threadleri başlatılır main thread
    #bu iki thread bitmeden devam etmez yani t3 threadini çalıştırmaz
    t1.join()
    t2.join()
    t3.start()
#ana program sonlandığında daemon threaadlerde otomotik olarak sonlanırşar bunları yönetmek gerekir ana program süresi uzun tutuşabilir ana program join işlemleri ile durdurularak daempn threadlere zaman kazandırılabilir
'''
non-daemon thread varsa ana program durdurulsada sonlandırılsada çalışmaya devaö eder
daemon thread ana programın durdurulması ile sona erer 

'''
def create_daemon_thread():
    def thread_5():
        print(f"this is a daemon thread with id {threading.get_native_id()}")
        while True:
            time.sleep(1)
            print(f"I am still alive because 1 am a dameon thread")

        print(f"I will never be printed because I am a daemond thread")
    def thread_6():
        print(f"this is a non-daemon thread with id {threading.get_native_id()}")
        time.sleep(5)
        print(f"I am done therefore the program wille exit")

    t1 = threading.Thread(target=thread_5)#t1 = threading.Thread(target=thread_5,daemon=True)
    t1.daemon = True
    t2 = threading.Thread(target=thread_6)
    t1.start()
    t2.start()

def combine_all_and_give_names_to_threads():
    def a_thread_to_join_1():
        print(f"this is thread 1 with id {threading.get_native_id()}")
        time.sleep(1)
        print(f"thread is done")
    
    def a_thread_to_join_2():
        print(f"this is thread 2 eith id {threading.get_native_id()}")
        time.sleep(1)
        print(f"thread 2 is done")
    def a_thread_after_join():
        print(f"this is thread 3 with id {threading.get_native_id()}")
        print(f"I can pnly start after thread 1 and thread 2 are done")
        time.sleep(1)
        print(f"thread 3 is done")
    
    def a_daemon_thread_running_in_background():
        print(f"this is a daemon thread with ig{threading.get_native_id()}")
        while True:
            time.sleep(1)
            print(f"I am still alive because I am a daemon thread")

    def a_non_daemon_thread():
        print(f"this is a non-daemon thread with id {threading.get_native_id()}")
        time.sleep(5)
        print(f"The program will exit when no non-daemon threads are left")

    t1 = threading.Thread(target=a_thread_to_join_1, name='Thread 1')
    t2 = threading.Thread(target=a_thread_to_join_2, name='Thread 2')
    t3 = threading.Thread(target=a_thread_after_join, name='Thread 3')
    t4 = threading.Thread(target=a_daemon_thread_running_in_background, name='Daemon Thread',daemon=True)
    t5 = threading.Thread(target=a_non_daemon_thread, name='Non-Daemon-Thread')

    t4.start()
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    #Ana program bitse bile altaki threadler non-daemon oldukları için ana program sonlandıktan sonrada çalışmaya devam eder
    t3.start()
    t5.start()

if __name__ == "__main__":
    print(f"This is the main thread with id: {threading.get_native_id()}")
    create_thread_from_function()
    create_thread_from_class()
    create_thread_from_function_and_pass_arguments()
    create_two_threads_and_join_them()
    create_daemon_thread()
    combine_all_and_give_names_to_threads() 





























