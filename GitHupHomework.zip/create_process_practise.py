import multiprocessing
import time
import os


def process_0():
    print(
        f"This is process 0 with id {multiprocessing.current_process().pid} == {os.getpid()}"
    )


def process_1():
    print(
        f"This is a process created from a function with id "
        f"{multiprocessing.current_process().pid} == {os.getpid()}"
    )
    time.sleep(5)


def process_2():
    print(f"This is a process created from a class with id {os.getpid()}")
    time.sleep(5)


def process_3(s):
    print(
        f"This is a process created from a function "
        f"with id {os.getpid()} "
        f"and your argument is {s}"
    )
    time.sleep(5)


def process_4_1():
    print(f"This is process 4_1 with id {os.getpid()}")
    time.sleep(1)
    print(f"Process 4_1 is done")


def process_4_2():
    print(f"This is process 4_2 with id {os.getpid()}")
    time.sleep(3)
    print(f"Process 4_2 is done")


def process_4_3():
    print(f"This is process 4_3 with id {os.getpid()}")
    print(f"I can only start after process 4_1 and process_4_2 are done")
    time.sleep(1)
    print(f"Process 4_3 is done")


def process_5():
    print(f"This is a daemon process with id {os.getpid()}")
    time.sleep(5)


class Process2(multiprocessing.Process):  # Global sınıf
    def __init__(self):
        super().__init__()

    def run(self):
        process_2()


# 1. Create a process from a function
def create_process_from_function():
    p = multiprocessing.Process(target=process_1)
    p.start()


# 2. Create a process from a class
def create_process_from_class():
    p = Process2()  # Global sınıf kullanılıyor
    p.start()


# 3. Create a process from a function and pass arguments
def create_process_from_function_and_pass_arguments():
    p = multiprocessing.Process(target=process_3, args=("Process 3",))
    p.start()


# 4. Create two processes and join them
def create_two_processes_and_join_them():
    p1 = multiprocessing.Process(target=process_4_1)
    p2 = multiprocessing.Process(target=process_4_2)
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    p3 = multiprocessing.Process(target=process_4_3)
    p3.start()


# 5. Create a daemon process
def create_daemon_process():
    p = multiprocessing.Process(target=process_5)
    p.daemon = True
    p.start()


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")  # Windows için gerekli
    print(f"Main process id: {os.getpid()}")
    create_daemon_process()
    create_process_from_function()
    create_process_from_class()
    create_process_from_function_and_pass_arguments()
    create_two_processes_and_join_them()


'''import multiprocessing
import time
import os
"""
This file includes the following ways to create a process:
1. Create a process from a function
2. Create a process from a class
3. Create a process from a function and pass arguments
4. Create two processes and join them
5. Create a daemon process
6. Combine all the above and give names to the processes
multiprocessing.current_process().pid} == {os.getpid} current_process fonksiyonu o anda çalışan processi döndürürü.pid ise pid numarasını döndürür
os.getpid() o anda işletim sisteminde çalışan benzersiz process pid id numarasını döndürür
os.getpid(bir işlemde çağrıldığında yalnızca o işlemin pid numarasını döndürür)
"""

def process_0():

    print(f"this is process 0 with id {multiprocessing.current_process().pid} == {os.getpid()}")
#Create process from a function 
def create_process_from_function():
    def process_1():
        print(f"this is a process created from a function with id"
              f"{multiprocessing.current_process().pid} == {os.getpid}"
        )
        time.sleep(5)

    p = multiprocessing.Process(target=process_1)
    p.start()

#Cretae process from a class
def create_process_from_class():
    class Process2(multiprocessing.Process):
        def __init__ (self):
            super().__init__()
        
        def run(self):
            print(f"this is a process from a class with id {os.getpid()}")
            time.sleep(5)
    p = Process2()
    p.start()
#Create process from a function and pass arguments
def create_process_from_function_and_pass_arguments():
    def process_3(s):
        print(
            f"this is a process created from a function"
            f"with id {ods.getpid()}"
            f"and your argument is {s}"
        )
        time.sleep(5)
        p = multiprocessing.Process(target=process_3, args=("Process 3",))
#Create two  proceess and join them
def create_two_processes_and_join_them():
    def process_4_1():
        print(f"This is process 4_1 with id {os.getpid()}")
        time.sleep(1)
        print(f"Process 4_1 is done")

    def process_4_2():
        print(f"This is process 4_2 with id {os.getpid()}")
        time.sleep(3)
        print(f"Process 4_2 is done")

    def process_4_3():
        print(f"This is process 4_3 with id {os.getpid()}")
        print(f"I can only start after process 4_1 and process 4_2 are done")
        time.sleep(1)
        print(f"Process 4_3 is done")
    p1 = multiprocessing.Process(target=process_4_1)
    p2 = multiprocessing.Process(target=process_4_2)
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    #üsteki iki process bitmeden p3 processi başlatılamaz
    p3 = multiprocessing.Process(target=process_4_3)
    p3.start()
    print(f"Process 4 is done")


#Create a daemon process
def create_daemon_process():
    def process_5():
       print(f"This is a daemon process with id {os.getpid()}")
       time.sleep(5)
    p = multiprocessing.Process(target=process_5)#ya da direk buraya da parametre olarak ekleyebilirsin
    p.daemon = True
    p.start() 

if __name__ == "__main__":
    # get the start method of the multiprocessing module
    # print(multiprocessing.get_start_method())
    # change the start method of the multiprocessing module to fork
    multiprocessing.set_start_method("spawn")
    # multiprocessing.set_start_method("spawn")
    # multiprocessing.set_start_method("forkserver")
    print(f"Main process id: {os.getpid()}")
    create_daemon_process()
    create_process_from_function()
    create_process_from_class()
    create_process_from_function_and_pass_arguments()
    create_two_processes_and_join_them()

'''










































































































'''import multiprocessing
import random
import numpy as np
import os


def generate_points(n, pipe):
    inner = 0
    for _ in range(n):
        x = random.random()
        y = random.random()
        if (x*2 + y*2) <= 1:
            inner += 1
    pipe.send(inner)
    pipe.close()


def pi(accuracy: float = 1.0e-5, number_of_processes: int = 1) -> float:
    def pi_(inner_: int, total_: int) -> float:
        try:
            return (inner_ / total_) * 4
        except ZeroDivisionError:
            return 0.0

    BATCH_SIZE = 1000000
    total = 0
    inner = 0
    process_count = 0
    while abs(pi_(inner, total) - np.pi) > accuracy:
        processes = []
        pipes = []
        for _ in range(number_of_processes):
            parent_conn, child_conn = multiprocessing.Pipe(False)
            p = multiprocessing.Process(
                target=generate_points, args=(BATCH_SIZE, child_conn)
            )
            processes.append(p)
            pipes.append(parent_conn)
            p.start()
        for p in processes:
            p.join()
        results = [pipe.recv() for pipe in pipes]
        inner += sum(results)
        total += len(results) * BATCH_SIZE
        process_count += len(results)
        print(
            f"inner: {inner}, total: {total}, "
            f"process_count: {process_count}, pi: {pi_(inner, total)}"
        )
    return pi_(inner, total)


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")
    print(pi(number_of_processes=os.cpu_count()))
    import psutil

    print(f"CPU Count: {psutil.cpu_count(logical=True)}")
    print(f"CPU Usage: {psutil.cpu_percent(interval=1, percpu=True)}")
'''