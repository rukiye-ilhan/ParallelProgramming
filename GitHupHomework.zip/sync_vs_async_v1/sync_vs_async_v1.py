'''
tarayicinin ve ya uygulamanin sunucuyla başarılı bir şekilde bağlandığını ancak
ancak talep edilen kaynağa erişim izninin olmadığını söyler
yerkisiz erişim:sadece yetkili kullanıcılar için sınırlanmış olabi,lir bu durumda özel bir apı adresine ihtiyaç duyulabilir
IP engelleme: sunucu belirli bir IP adreslerini angelleyebilir örneğin aşırı istek gönderen IP adresleri kara listeye alınabilir
Yanlış başlık(HEADER)  bilgisi yalnızca belirli User-Agent başlıklarına izin veriri 
başlık belirli bir tarayıcıyı taklit edecek şekilde ayarlanabilir
Bölgesel Kısıtlamalar
Bazı siteler, belirli ülkelerden gelen trafiği sınırlayabilir. Bu durumda, bir VPN kullanarak başka bir ülkeden bağlanmak çözüm olabilir.
5. Kötüye Kullanım Önleme
Çoğu sunucu, belirli bir süre içinde çok fazla istek gönderildiğinde erişimi geçici olarak engeller. Bu durumda, istek sıklığını azaltarak tekrar deneyebilirsiniz.
'''
'''import requests

BASE_URL = "https://www.canbula.com/prime"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
} 
def sync_request(n: int) -> dict:
    # Basic synchronous request
    
    #get isteği ile n değerleriyle dinamik olarak değişen http
    #sayfalarına istek yapılır gelen response json formatında olup bunnu  dict'e çavirmek için
    #response.json()ile json formatşı response dict türüne döner
  
    response = requests.get(f"{BASE_URL}/{n}",headers = headers)
    
    print(response.status_code)
    #print(f"Sync request {n} done")
    return response.json()


if __name__ == "__main__":
    result = sync_request(100)
    print(result)'''

'''import requests

BASE_URL = "https://www.canbula.com/prime"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
} 

def sync_requset(n: int ):
    #Synchronuos request with error handling
    try:
        response = requests.get(f"{BASE_URL}/{n}", headers = headers)
        response.raise_for_status()
        return response.json()
        #RequestException sınıfı, tüm diğer spesifik istisna sınıflarının (örneğin HTTPError, ConnectionError, Timeout, vb.) üst sınıfıdır.

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return{}'''

import requests
import logging


logging.basicConfig(
     format="%(levelname)s @ %(asctime)s : %(message)s",
     datefmt="%d.%m.%Y %H:%M:%S",
     level = logging.DEBUG,
     handlers = [logging.FileHandler("request.log",mode = "w"),logging.StreamHandler()],
)
BASE_URL  = "https://www.canbula.com/prime"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
} 

def sync_request(n: int) ->dict:
    #syncronous request with error handling and logging
    try:
        response = requests.get(f"{BASE_URL}/{n}")
        response = response.raise_for_status()
        logging.debug(f"Request returned with status code {response.status_code}", headers = headers)
        return response.json()
    except requests.exceptions.RequestException as e:
        logging.error(f"Requestfor {n} failed: {e}")
        return {}

if __name__ == "__main__":
    result = sync_request(5)
    print(result)




