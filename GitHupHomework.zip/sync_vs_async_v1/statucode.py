import requests

BASE_URL = "https://www.canbula.com/prime"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
} 
def sync_request(n: int) -> dict:
    # Basic synchronous request
    
    #get isteği ile n değerleriyle dinamik olarak değişen http
    #sayfalarına istek yapılır gelen response json formatında olup bunnu  dict'e çavirmek için
    #response.json()ile json formatşı response dict türüne döner
  
    response = requests.get(f"{BASE_URL}/{n}",headers = headers)
    print(response.status_code)
    #print(f"Sync request {n} done")
    return response.json()


if __name__ == "__main__":
    result = sync_request(100)
    print(result)