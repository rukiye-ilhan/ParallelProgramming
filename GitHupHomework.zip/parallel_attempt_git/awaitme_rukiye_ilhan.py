import asyncio
def awaitme(func):
    async def wrapper(*args,**kwargs):
        rslt = func(*args,**kwargs)
        if asyncio.iscoroutine(rslt):
            return await rslt
        return rslt
    return wrapper

@awaitme
def function(x: int, y: int):
    return x + y
result = asyncio.run(function(1, 3))
print(result)





'''import asyncio

def decorator(func):
    async def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        #print(result)
        if asyncio.iscoroutine(result):  # result'un coroutine olup olmadığını kontrol etmeliyiz
            result = await result
            print(result)
            return result
            #fonksiyonu return değeri varsa fonksiyonu direk ismen değil çağırınca return eden değeri tutman gererkir
        #print(result)  # result coroutine değilse burada yazdırılacak
        return result
    return wrapper

@decorator
def function(x: int, y: int):
    return x + y

# Asenkron fonksiyonu çalıştırmak için asyncio.run kullanın
asyncio.run(function(1, 3))'''




'''import asyncio
def decorator(func):
    async def wrapper(*args,**kwargs):
        result = func(*args,**kwargs)
        if asyncio.iscoroutine(func):
            res = await func(*args,**kwargs)
            print(res)
            return res
        return result
    return wrapper

@decorator
def function(x : int ,y: int):
    #await asyncio.sleep(second)
    return x + y

asyncio.run(function(1,3))'''
'''
import asyncio
async def get_data(second: int = 0):
    print("fetching data...")
    await asyncio.sleep(second)
    return second

async def main():
    await get_data(3)
    
asyncio.run(main())'''