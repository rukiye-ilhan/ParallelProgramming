import threading
import random
import numpy as np
from numba import jit


class PiEstimatorThread(threading.Thread):
    def __init__(
        self,
        number_of_points: int = 100000,
        name="Generator",
    ):
        super().__init__(name=name)
        self.number_of_points = number_of_points
        self.inner_points = 0
        self.total_points = 0
    '''
    @jit(nopython=True, nogil=True): Bu, numba kütüphanesinin JIT (Just-In-Time) derleme dekoratörüdür.
    Performans artırımı sağlamak amacıyla, fonksiyonu derler ve Python yorumlayıcısının dışına çıkarır.
    nogil=True ifadesi ise Python Global Interpreter Lock (GIL) kilidini devre dışı bırakır ve çok iş parçacıklı (multi-threaded) uygulamalarda performansı artırabilir.    
    '''
    @staticmethod#bu keyword generate_points fonksiyonumuzu statik yapar statik metotlar direk class üzerinden çağrılırlar nesneye ihtiyaç duymazlar herhangi bir nesneye bağlı olmadan çalıştırılabilirliği self kullanımını önler
    @jit(nopython=True, nogil=True)
    def generate_points(n):
        inner_points = 0
        total_points = 0
        for _ in range(n):
            x = random.random()
            y = random.random()
            if x ** 2 + y ** 2 <= 1:
                inner_points += 1
            total_points += 1
        return inner_points, total_points
    #self'leri aşağıdaki gibi sonradan yazmamızın sebebi decaratorlerın kabul ettiği fonlsiyonların içinde 
    def run(self):
        self.inner_points, self.total_points = self.generate_points(self.number_of_points)

class PiEstimator(threading.Thread):
    def __init__(
        self,
        desired_accuracy: float = 1.0e-4,
        number_of_threads: int = 2,
        chunk_size: int = 100,
        name="PI Estimator",
    ):
        super().__init__(name=name)
        self.desired_accuracy = desired_accuracy
        self.number_of_threads = number_of_threads
        self.chunk_size = chunk_size
        self.inner_points = 0
        self.total_points = 0
        self.generated_threads = 0

    def pi(self):
        try:
            return 4 * self.inner_points / self.total_points
        except ZeroDivisionError:
            return 0.0

    def accuracy(self):
        return abs(np.pi - self.pi())

    max_iterations = 1000  # Örneğin 1000
    iteration_count = 0
    def run(self):
        #max_iterations = 1000  # Örneğin 1000
        #iteration_count = 0
        while self.accuracy() > self.desired_accuracy :
            #iteration_count += 1
            threads = []
            for _ in range(self.number_of_threads):
                threads.append(
                    PiEstimatorThread(
                        number_of_points=self.chunk_size,
                        name=f"Generator - {self.generated_threads}",
                    )
                )
                self.generated_threads += 1
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()
            for thread in threads:
                self.inner_points += thread.inner_points
                self.total_points += thread.total_points

            #if iteration_count >= max_iterations:
                #print("Maksimum iterasyon sayısına ulaşıldı!")

    def join(self, timeout=None):
        super().join()
        print(f"Final estimation of Pi: {self.pi()}")
        print(f"Accuracy: {self.accuracy()}")
        print(f"Number of total points: {self.total_points}")
        print(f"Number of inner points: {self.inner_points}")
        print(f"Number of threads: {self.generated_threads}")


if __name__ == "__main__":
    pi_estimator = PiEstimator(
        desired_accuracy=1.0e-8,
        number_of_threads=2,
        chunk_size=100,
        name="Pi Estimator",
    )
    pi_estimator.start()
    pi_estimator.join()
    
'''PS C:\ParallelProgrammingVSCode> & C:/ProgramData/Anaconda3/python.exe c:/ParallelProgrammingVSCode/estimate_p_w_threads_nogil_practise.py
Final estimation of Pi: 3.141592653705431
Accuracy: 1.1563772162048735e-10
Number of total points: 13939000
Number of inner points: 10947665
Number of threads: 139390
PS C:\ParallelProgrammingVSCode> '''